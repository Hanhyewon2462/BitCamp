package com.daycon.buddyheal.dto;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.swing.tree.TreePath;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.RowMapper;
import com.daycon.buddyheal.model.UserInfoVO;

@Repository
public class UserRepositoryImpl implements UserRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class userMapper implements RowMapper<UserInfoVO>{
		public UserInfoVO mapRow(ResultSet rs, int count) throws SQLException{
			UserInfoVO user = new UserInfoVO();
			user.setUser_email(rs.getString("user_email"));
			user.setUser_name(rs.getString("user_name"));	
			return user;
		}
	}

	


    @Override
    public String getUserInfo(String email) {
        String sql = "SELECT user_name FROM user_info WHERE user_email = mhee116677@gmail.com";
        try {
            return jdbcTemplate.queryForObject(sql, String.class);
        } catch (EmptyResultDataAccessException e) {
            // 이메일이 존재하지 않는 경우 처리
            System.out.println("No user found with email: " + email);
            return null;
        } catch (Exception e) {
            // 기타 예외 처리
            e.printStackTrace();
            return null;
        }
    }
	  
	public void registerUser(String email, String name) {
		String sql = "INSERT INTO user_info(user_email,user_name) VALUES(?,?)";
		jdbcTemplate.update(sql,email,name);
	}

}
