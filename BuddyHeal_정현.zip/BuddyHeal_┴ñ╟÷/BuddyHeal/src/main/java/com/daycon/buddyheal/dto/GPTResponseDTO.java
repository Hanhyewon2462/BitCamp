package com.daycon.buddyheal.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GPTResponseDTO {

	private List<Choice> choices;
	
	@Data
	@AllArgsConstructor
	@NoArgsConstructor
	public static class Choice {
		//gpt 대화 인덱스 번호
		private int index;
		// 지피티로부터 받은 response 응답 메세지
		private Message message;
		
		
	}
}
