package com.javaEdu.myapp.hr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.javaEdu.myapp.hr.model.BoardVO;

@Repository
@Transactional
public class BoaRepository implements IBoaRepository {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private class BoaMapper implements RowMapper<BoardVO> {
		@Override
		public BoardVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			BoardVO boa = new BoardVO();
			boa.setBoard_Id(rs.getInt("board_Id"));
			boa.setTitle(rs.getString("title"));
			boa.setAuthor(rs.getString("author"));
			boa.setContent(rs.getString("content"));
			boa.setCount(rs.getInt("count"));
			boa.setLikes(rs.getInt("likes"));
			boa.setIs_public(rs.getInt("is_public"));
			boa.setRegdate(rs.getDate("regdate"));
			return boa;
		}
	}
	
	@Override
	public int getAllBoardCount() {
		String sql = "select count(*) from board";
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

	@Override
	public void writeBoard(BoardVO boa) {
		try {
				String sql = "insert into board(title, author, content, count, likes, is_public, regdate) values(?,?,?,?,?,?,sysdate)";
				jdbcTemplate.update(sql, boa.getTitle(), boa.getAuthor(), boa.getContent(), boa.getCount(), boa.getLikes(), boa.getIs_public());
		}catch(DataAccessException e) {
			 e.printStackTrace(); // �α׸� ����ų� ������ ó���ؾ� �մϴ�.
		}
	}

	// Ư�� �Խñ� ��ȸ
	@Override
	public BoardVO getBoard(int board_Id) {
		String sql = "select board_Id, title, author, content, count, likes, is_public, regdate from board where board_Id = ?";
		return jdbcTemplate.queryForObject(sql, new BoaMapper(), board_Id);
	}

	@Override
	public void updateBoard(BoardVO boa) {
		String sql = "update board set content = ?, is_public = ?, title = ? where board_Id = ?";
		jdbcTemplate.update(sql, boa.getContent(), boa.getIs_public(), boa.getTitle(), boa.getBoard_Id()); // board_Id �߰�
	}

	@Override
	public void deleteBoard(int board_Id) {
		String sql = "delete from board where board_Id = ?";
		jdbcTemplate.update(sql, board_Id);
	}

	@Override
    public List<BoardVO> getBList() {
        String sql = "select * from board";
        return jdbcTemplate.query(sql, new BoaMapper());
    }
	
	@Override
	public List<BoardVO> findAllByOrderByBoardIdDesc() {
		String sql = "select * from board ORDER BY board_Id ASC";
		 return jdbcTemplate.query(sql, new BoaMapper());
	}

	@Override
	public void likeBoard(int board_Id) {
		String sql = "update board set likes = likes + 1 where board_Id = ?";
		jdbcTemplate.update(sql, board_Id);	
	}

	@Override
	public void setPublic(int board_Id, boolean is_public) {
		String sql = "update board set is_public = ? where board_Id = ?";
		jdbcTemplate.update(sql, is_public, board_Id);	
	}
}
