package com.javaEdu.myapp.hr.service;

	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.javaEdu.myapp.hr.dao.IMemberRepository;
import com.javaEdu.myapp.hr.model.MemberVO;


	@Service
	public class MemberService implements IMemberService {
		
		@Autowired
		private IMemberRepository mbRepository;
		
		@Override
		public boolean join(MemberVO mb) {
			try {
		       mbRepository.join(mb);
		       return true;
			}catch(Exception e) {
			   return false;
			}
		}

		@Override
		public MemberVO getMyInfo(String memberId) {
			try {
			  return mbRepository.getMyInfo(memberId);	
		}catch(EmptyResultDataAccessException e) {
			  return null;
		} catch (Exception e) {
            e.printStackTrace();
            return null;
		}
	}
		
		@Override
		public boolean updateMyInfo(MemberVO mb) {
			try {
			return mbRepository.updateMyInfo(mb);
		}catch(EmptyResultDataAccessException e) {
			return false;
		}
	}

		@Override
		public boolean quitMyInfo(String memberId) {
			return mbRepository.quitMyInfo(memberId);
		}

		@Override
		public boolean login(String memberId, String pwd) {
			try {
			MemberVO member = mbRepository.getMyInfo(memberId); // ȸ�� ���� ��ȸ
			if (member != null && member.getPwd().equals(pwd)) {
				// �α��� ���� ó��(���� ���)
				// ���� ������ ��Ʈ�ѷ�����
				return true; //�α��� ����
			}
			return false; //�α��� ����
		}catch(Exception e) {
			e.printStackTrace(); //���� �߻� �� �α� ���
		    return false;
		}
	}
}