document.addEventListener('DOMContentLoaded', function() {
    const track = document.querySelector('.carousel_track');
    const slides = Array.from(track.children);
    const prevButton = document.querySelector('.button_prev');
    const nextButton = document.querySelector('.button_next');
    const progressBar = document.querySelector('.carousel_progress');
    const currentIndexElement = document.querySelector('.current_cnt');
    const totalSlidesElement = document.querySelector('.total_cnt');
    let currentSlideIndex = 0;
    const slideCount = slides.length;

    const updateSlidePosition = () => {
        slides.forEach((slide, index) => {
            slide.classList.toggle('current_slide', index === currentSlideIndex);
        });
        currentIndexElement.textContent = `0${currentSlideIndex + 1}`;
        progressBar.style.width = `${((currentSlideIndex + 1) / slideCount) * 100}%`;
    };

    nextButton.addEventListener('click', () => {
        if (currentSlideIndex === slideCount - 1) {
            currentSlideIndex = 0;
        } else {
            currentSlideIndex++;
        }
        updateSlidePosition();
    });

    prevButton.addEventListener('click', () => {
        if (currentSlideIndex === 0) {
            currentSlideIndex = slideCount - 1;
        } else {
            currentSlideIndex--;
        }
        updateSlidePosition();
    });

    totalSlidesElement.textContent = `0${slideCount}`;
    updateSlidePosition();

    // Automatic playback
    setInterval(() => {
        nextButton.click();
    }, 5000); // Change slide every 5 seconds
});