package com.daycon.buddyheal.dto;

public interface ChatLogRepository {

}
