package com.daycon.buddyheal.config;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestTemplate;

import com.daycon.buddyheal.service.GPTServiceImpl;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Configuration
@PropertySource("classpath:/properties/gpt.properties")
public class GPTConfig {

	 @Value("${gpt.api.key}")
	   private String apiKey;
	 
	 @Value("${gpt.api.url}")
	   private String apiUrl;
	 
	 @Value("${gpt.model}")
	 	private String model;
	
	//모든 요청에 대해 openai api 키를 포함시킴. 
	@Bean 
	//RestTemplate -> http 요청을 보내고 응답을 받을 때 사용되는 객체. . 
	public RestTemplate restTemplate() {
		RestTemplate template = new RestTemplate();
		template.getInterceptors().add((request,body,execution)->{ //RestTemplate에 인터셉터 추가 -> http 요청과 응답을 가로채어 처리할 수 있는 기능 제공
     
			request.getHeaders().add( //헤더에 추가. -> 인증 헤더 구성.
					"Authorization",
					"Bearer "+ apiKey); //bearer -> 클라이언트가 서버에 요청할 때, authorization 헤더에 bearer 토큰(api key)을 포함하여 인증을 수행하는 방법
			request.getHeaders().setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
		
			  // 요청 URL 및 헤더 출력
	      
	      
			return execution.execute(request, body); // 수정된 요청을 실행 후 결과 반환. 

		});
		return template; 
	}
	
	 @Bean
	    public GPTServiceImpl gptService(RestTemplate restTemplate) {
	        return new GPTServiceImpl(restTemplate, apiUrl, apiKey, model);
	    }
}
