package com.javaEdu.myapp.hr.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.javaEdu.myapp.hr.model.MemberVO;

@Repository
@Transactional
public class MemberRepository implements IMemberRepository {
		
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private HttpSession httpSession;
	
	private class MemberMapper implements RowMapper<MemberVO> {
		@Override
		public MemberVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			MemberVO mb = new MemberVO();
			mb.setAddress(rs.getString("address"));
			mb.setEmail(rs.getString("email"));
			mb.setJoinDate(rs.getDate("joindate"));
			mb.setMemberId(rs.getString("member_id"));
			mb.setName(rs.getString("name"));
			mb.setPhone(rs.getString("phone"));
			mb.setPwd(rs.getString("pwd"));
			mb.setQuitYn(rs.getString("quit_yn"));
			return mb;
		}
	}
	
	@Override
	public boolean join(MemberVO mb) {
		String sql = "INSERT INTO member (member_id, pwd, name, address, phone, email, quit_yn, joindate) VALUES (?, ?, ?, ?, ?, ?, ?,sysdate)";
		
		try {
			jdbcTemplate.update(sql, mb.getMemberId(), mb.getPwd(), mb.getName(), mb.getAddress(), mb.getPhone(), mb.getEmail(), mb.getQuitYn());
			return true;
		}catch(DataAccessException e) {
	        e.printStackTrace(); // �α׸� ����ų� ������ ó���ؾ� �մϴ�.
			return false;
		}
	}
	
	@Override
	public MemberVO getMyInfo(String memberId) {
		//MemberVO rtnVo = new MemberVO();
		System.out.println("--- getMyInfo ���� ---" +memberId);
		String sql = "select * from member where member_id=?";
		System.out.println("--- sql ::"+sql);
		
		try {	
			return jdbcTemplate.queryForObject(sql, new MemberMapper(), memberId);
		}catch(EmptyResultDataAccessException e) {
			// ȸ�������� ���� ���
			return null;
		 } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }
	
	@Override
	public boolean updateMyInfo(MemberVO mb) {
		System.out.println("-- updateMyInfo ����" +mb.getMemberId());
		//mb=null;
		String sql = "update member set pwd=?, name=?, address=?, email=?, phone=? where member_id=?";
		System.out.println("--updateSQL--"+sql);
		try {
			jdbcTemplate.update(sql, mb.getPwd(), mb.getName(),mb.getAddress(), mb.getEmail(), mb.getPhone(), mb.getMemberId());
			return true;
	    }catch(DataAccessException e) {
			e.printStackTrace();
			return false;
	    }
	}
	
	@Override
	public boolean quitMyInfo(String memberId) {
		String sql = "update member set quit_yn='Y' where member_id=?";
		jdbcTemplate.update(sql, memberId);
		return true;
	}
	
	@Override
	public boolean login(String memberId, String pwd) {
		String sql = "select count(*) from member where member_id=? and pwd=?";
		Integer count = jdbcTemplate.queryForObject(sql, Integer.class, memberId, pwd);
			 return count != null && count > 0;
		}
   }
