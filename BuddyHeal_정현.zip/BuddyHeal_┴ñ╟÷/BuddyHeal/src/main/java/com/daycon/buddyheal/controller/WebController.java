package com.daycon.buddyheal.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebController {
	// ê�� �������� �̵�
	@GetMapping("/chatbot")
	public String moveChatbot(Model model) {
	    return "/chatbot/didimi";
	}
	
	// ������ �������� �̵�
	@GetMapping("/morbidity")
	public String moveMorbidity(Model model) {
	    return "/morbidity/analysis";
	}
}