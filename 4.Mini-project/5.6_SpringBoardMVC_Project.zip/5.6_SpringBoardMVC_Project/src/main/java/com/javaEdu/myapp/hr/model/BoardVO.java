package com.javaEdu.myapp.hr.model;

import java.sql.Date;
import java.sql.Timestamp;

public class BoardVO {

	private String title;
	private String author;
	private String content;
	private Date regdate;
	private int count;
	private int likes;
	private int is_public;
	private int board_Id;
	private Date createdAt;
	
	@Override
	public String toString() {
		return "BoardVO[title="+ title+ ", author=" +author
				+",content=" + content + ",regdate=" + regdate
				+",count=" +count+ ",likes=" +likes
				+",is_public=" +is_public+ ",board_Id=" + board_Id+"]";
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int like) {
		this.likes = like;
	}
	public int getIs_public() {
		return is_public;
	}
	public void setIs_public(int is_public) {
		this.is_public = is_public;
	}
	   public int getBoard_Id() {
	        return board_Id;
	    }

    public void setBoard_Id(int board_Id) {
        this.board_Id = board_Id;
    }
	public void setRegdate(Date regdate) {
		this.regdate=regdate;
	}

	public Date getRegdate() {
		return regdate;
	}
	
	 public Date getCreatedAt() {
	        return createdAt;
	    }

	    public void setCreatedAt(Date createdAt) {
	        this.createdAt = createdAt;
	    }

}





