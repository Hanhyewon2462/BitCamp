package com.javaEdu.myapp.hr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javaEdu.myapp.hr.dao.IBoaRepository;
import com.javaEdu.myapp.hr.model.BoardVO;

@Service
public class BoaService implements IBoaService {
	
	@Autowired
	private IBoaRepository boaRepository;

	@Override
	public int getAllBoardCount() {
		return boaRepository.getAllBoardCount();
	}

	@Override
	public void writeBoard(BoardVO boa) {
		boaRepository.writeBoard(boa);
	}

	@Override
	public BoardVO getBoard(int board_Id) {
		return boaRepository.getBoard(board_Id);
	}

	@Override
	public void updateBoard(BoardVO boa) {
		boaRepository.updateBoard(boa);
	}

	@Override
	public void deleteBoard(int board_Id) {
		boaRepository.deleteBoard(board_Id);
	}

	@Override
	public List<BoardVO> getBList() {
		return boaRepository.getBList();
	}
	
	@Override
	public List<BoardVO> findAllByOrderByBoardIdDesc() {
		return boaRepository.findAllByOrderByBoardIdDesc();
	}

	@Override
	public void likeBoard(int board_Id) {
		boaRepository.likeBoard(board_Id);
	}

	@Override
	public void setPublic(int board_Id, boolean is_public) {
		boaRepository.setPublic(board_Id, is_public);
	}
	
}

