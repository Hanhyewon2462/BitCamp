package com.javaEdu.myapp.hr.model;
import java.sql.Date;

	public class MemberVO {
		
		private String memberId;
		private String pwd;
		private String name;
		private String address;
		private String phone;
		private String email;
		private String quitYn;
		private Date joinDate;
		
		public String getMemberId() {
			return memberId;
		}
		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}
		public String getPwd() {
			return pwd;
		}
		public void setPwd(String pwd) {
			this.pwd = pwd;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getQuitYn() {
			return quitYn;
		}
		public void setQuitYn(String quitYn) {
			this.quitYn = quitYn;
		}
		public Date getJoinDate() {
			return joinDate;
		}
		public void setJoinDate(java.util.Date joinDate) {
			this.joinDate = (Date) joinDate;
		}
		
}