package com.daycon.buddyheal.dto;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.daycon.buddyheal.model.UserInfoVO;

@Repository
public interface UserRepository {
	public String getUserInfo(String email);
	public void registerUser(String name, String email);
}
