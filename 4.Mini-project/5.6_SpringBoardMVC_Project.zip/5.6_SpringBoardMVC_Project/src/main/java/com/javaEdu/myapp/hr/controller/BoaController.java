package com.javaEdu.myapp.hr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.javaEdu.myapp.hr.model.BoardVO;
import com.javaEdu.myapp.hr.service.IBoaService;

@Controller
public class BoaController {

    @Autowired
    IBoaService boaService;

    @GetMapping(value = "/")
    public String home() {
        return "hr/index";
    }
    
    // �Խñ� ��ü �� ��ȸ
    @GetMapping("/hr/count")
    public String boardCount(Model model) {
        int count = boaService.getAllBoardCount();
        model.addAttribute("count", count);
        return "hr/count";
    }

    // �Խñ� ��� ��ȸ
    @GetMapping("/hr/list")
    public String boardList(Model model) {
        List<BoardVO> boardList = boaService.findAllByOrderByBoardIdDesc();
        model.addAttribute("boardList", boardList);
        return "hr/list";
    }

    // �Խñ� �� ��ȸ
    @GetMapping("/hr/{board_Id}")
    public String boardDetail(@PathVariable int board_Id, Model model) {
    	System.out.println("�Խñ� ����ȸ::["+board_Id+"]");
        BoardVO board = boaService.getBoard(board_Id);
        if(board == null) {
        	System.out.println("�Խñ��� �������� �ʽ��ϴ�. ID: "+board_Id);
        	return "redirect:/hr/list";
        }
        model.addAttribute("detail", board);
        return "hr/detail";
    }

    // �Խñ� �ۼ� ��
    @GetMapping("/hr/write")
    public String writeForm(Model model) {
        model.addAttribute("board", new BoardVO());
        return "hr/writeform";
    }

    // �Խñ� �ۼ� ó��
    @PostMapping("/hr/write")
    public String write(@ModelAttribute("board") BoardVO boa) {
        boaService.writeBoard(boa);
        return "redirect:/hr/list";
    }

    // �Խñ� ���� ��
    @GetMapping("/hr/update/{board_Id}")
    public String updateForm(@PathVariable int board_Id, Model model) {
        BoardVO board = boaService.getBoard(board_Id);
        model.addAttribute("board", board);
        return "hr/updateform";
    }

    // �Խñ� ���� ó��
    @PostMapping("/hr/update/{board_Id}")
    public String update(@PathVariable int board_Id, @ModelAttribute("board") BoardVO board) {
        board.setBoard_Id(board_Id);
        boaService.updateBoard(board);
        return "redirect:/hr/" + board_Id;
    }

    // ���� ó��
    @PostMapping("/hr/delete/{board_Id}")
    public String deleteBoard(@PathVariable int board_Id) {
    	System.out.println("--����ó��:" +board_Id);
        boaService.deleteBoard(board_Id);
        return "redirect:/hr/list";
    }
}
