package com.daycon.buddyheal.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
//json 이름 변환 전략 지정. jackson이 json을 역/직렬화할 때 필드 이름을 특정 형식으로 변환. 
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)// -> 어차피 지금 필요하진 않음. 차라리 필드 이름을 모두 카멜케이스로 고정하면 안되려나

public class GPTRequestDTO {

	private String model;
    private List<Message> messages;
    private int temperature;
    private int maxTokens;
    private int topP;
    private int frequencyPenalty;
    private int presencePenalty;

    public GPTRequestDTO(String model
            , String prompt
            , int temperature
            , int maxTokens
            , int topP
            , int frequencyPenalty
            , int presencePenalty) {
        this.model = model;
        this.messages = new ArrayList<>();
        this.messages.add(new Message("user",prompt));
        this.temperature = temperature;
        this.maxTokens = maxTokens;
        this.topP=topP;
        this.frequencyPenalty=frequencyPenalty;
        this.presencePenalty = presencePenalty;

    }
	
}
