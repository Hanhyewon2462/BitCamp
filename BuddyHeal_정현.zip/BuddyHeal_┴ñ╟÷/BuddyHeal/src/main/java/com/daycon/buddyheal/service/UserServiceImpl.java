package com.daycon.buddyheal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.daycon.buddyheal.dto.UserRepository;
import com.daycon.buddyheal.model.UserInfoVO;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserRepository user;
	
	@Override
	public UserInfoVO registerOrLogin(String email, String name) {
		String user_name = user.getUserInfo(email);
	
		UserInfoVO user_info = new UserInfoVO();
		user_info.setUser_email(email);
		user_info.setUser_name(name);
		if(user_name==null) {
			user.registerUser(email,name);
		}
		System.out.println(user_info);
		return user_info;
	}

	
}
